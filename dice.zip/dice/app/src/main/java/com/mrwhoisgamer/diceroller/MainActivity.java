package com.mrwhoisgamer.diceroller;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import java.util.Random;

public class MainActivity extends AppCompatActivity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }

    public void clicked(View view){
        int r1 = genraterandomno();
        int r2 = genraterandomno();
        int r3 = genraterandomno();
        int r4 = genraterandomno();
        ImageView imageView1 = findViewById(R.id.imageView1);
        ImageView imageView2 = findViewById(R.id.imageView2);
        ImageView imageView3 = findViewById(R.id.imageView3);
        ImageView imageView4 = findViewById(R.id.imageView4);
        presstoroll1(r1,imageView1);
        presstoroll2(r2,imageView2);
        presstoroll2(r3,imageView3);
        presstoroll2(r4,imageView4);
    }
        public int genraterandomno(){
            Random randomno = new Random();
            int randomnum=randomno.nextInt(6)+1;
            return randomnum;
        }
    public void presstoroll1(int r1,ImageView imageView1){

        switch(r1){
            case 1:
                imageView1.setImageResource(R.drawable.dice1);
                break;
            case 2:
                imageView1.setImageResource(R.drawable.dice2);
                break;
            case 3:
                imageView1.setImageResource(R.drawable.dice3);
                break;
            case 4:
                imageView1.setImageResource(R.drawable.dice4);
                break;
            case 5:
                imageView1.setImageResource(R.drawable.dice5);
                break;
            case 6:
                imageView1.setImageResource(R.drawable.dice6);
                break;
        }
    }
    public void presstoroll2(int r2,ImageView imageView2){

        switch(r2){
            case 1:
                imageView2.setImageResource(R.drawable.dice1);
                break;
            case 2:
                imageView2.setImageResource(R.drawable.dice2);
                break;
            case 3:
                imageView2.setImageResource(R.drawable.dice3);
                break;
            case 4:
                imageView2.setImageResource(R.drawable.dice4);
                break;
            case 5:
                imageView2.setImageResource(R.drawable.dice5);
                break;
            case 6:
                imageView2.setImageResource(R.drawable.dice6);
                break;
        }
    }
    public void presstoroll3(int r3,ImageView imageView3){

        switch(r3){
            case 1:
                imageView3.setImageResource(R.drawable.dice1);
                break;
            case 2:
                imageView3.setImageResource(R.drawable.dice2);
                break;
            case 3:
                imageView3.setImageResource(R.drawable.dice3);
                break;
            case 4:
                imageView3.setImageResource(R.drawable.dice4);
                break;
            case 5:
                imageView3.setImageResource(R.drawable.dice5);
                break;
            case 6:
                imageView3.setImageResource(R.drawable.dice6);
                break;
        }
    }
    public void presstoroll4(int r4,ImageView imageView4){

        switch(r4){
            case 1:
                imageView4.setImageResource(R.drawable.dice1);
                break;
            case 2:
                imageView4.setImageResource(R.drawable.dice2);
                break;
            case 3:
                imageView4.setImageResource(R.drawable.dice3);
                break;
            case 4:
                imageView4.setImageResource(R.drawable.dice4);
                break;
            case 5:
                imageView4.setImageResource(R.drawable.dice5);
                break;
            case 6:
                imageView4.setImageResource(R.drawable.dice6);
                break;
        }
    }
    }
